<?php
$connection = mysql_connect('localhost','root','') or die(mysql_error());
$database = mysql_select_db('sales') or die(mysql_error());
?>
