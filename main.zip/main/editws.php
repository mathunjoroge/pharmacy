<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<form action="saveeditws.php" method="post">
<center><h4><i class="icon-edit icon-large"></i> Edit discount</h4></center>
<hr>

<div id="ac">
<span>edit discount: </span><input type="number" style="width:200px; height:30px;" name="a"/>%<br>

<div style="float:right; margin-right:10px;">

<button class="btn btn-success btn-block btn-large" style="width:267px;float: left;"><i class="icon icon-save icon-large"></i> Save Changes</button>
</div>
</div>
</form>
